# Lecture_Notes
This repository is there to store the combined lecture notes of all the lectures. We are using markdown to write the lecture notes.
