Numbering 1,2,3, as per images in the article.
